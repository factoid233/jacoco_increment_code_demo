package com.demo.controller;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@EnableAutoConfiguration
@RequestMapping("/api")
public class DemoController {
    private static final Logger logger = LoggerFactory.getLogger(DemoController.class);

    @RequestMapping("/")
    String home(){
        return "hello, world!";
    }
    @GetMapping("/add")
    public int add(@RequestParam(value = "x",required = true) int x, @RequestParam(value = "y",required = true) int y){
        logger.info("run add");
        logger.info("呵呵哒add");
        return x+y;
    }
    @GetMapping("/mul")
    public int mul(@RequestParam(value = "x",required = true) int x, @RequestParam(value = "y",required = true) int y){
        logger.info("呵呵哒 run mul");
        return x*y;
    }
    @GetMapping("/div")
    public int div(@RequestParam(value = "x",required = true) int x, @RequestParam(value = "y",required = true) int y){
        logger.info("run mul");
        return x/y;
    }
    @GetMapping("/demo")
    public int demo(@RequestParam(value = "x",required = true) int x){
        logger.info("demo");
        switch (x){
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            default:
                return -1;
        }
    }

}
